import Foundation

struct Element{
    static var globalId: Int = 1
    
    init(row: Int, col: Int, append: Bool) {
        self.row = row
        self.col = col
        self.append = append
        self.id = Element.globalId
        Element.globalId += 1
    }
    var id: Int
    var row: Int
    var col: Int
    var append: Bool
}

let colMaxNum = 4
var currentRow:Int = 0
var currentCol: Int = 0
var dataMatrix: [[Int]] = []

var elements: [Element] = []
elements.append(Element(row: 3,col: 1, append: true))
elements.append(Element(row: 1,col: 1, append: true))
elements.append(Element(row: 1,col: 3, append: true))
elements.append(Element(row: 2,col: 1, append: true))
elements.append(Element(row: 1,col: 1, append: true))
elements.append(Element(row: 4,col: 1, append: true))
elements.append(Element(row: 1,col: 4, append: true))
elements.count


func goToNextRow(){
    currentRow += 1
    addEmptyRow(currentRow)
}

func addEmptyRow(_ size: Int){
    let neccesarySize = size + 1
    if dataMatrix.count <= neccesarySize {
        dataMatrix.append([])
        for _ in 0..<colMaxNum {
            dataMatrix[neccesarySize].append(0)
        }
    }
}

func addElementOnGrid(_ currentElement: Element){
    let startRowIndex = currentRow
    let endRowIndex = currentElement.row + currentRow - 1
    let endColNum = currentCol + currentElement.col
    var lastRow: Bool = false
    
    for rowIndex in startRowIndex...endRowIndex{
        for index in currentCol..<endColNum {
            dataMatrix[rowIndex][index] = currentElement.id
        }
        lastRow = (rowIndex == (endRowIndex))
        if (!lastRow) {
            addEmptyRow(rowIndex)
        }
    }
    currentCol = endColNum
}

func canAddOnRaw(_ currentElement: Element) -> Bool{
    let endColNum = currentCol + currentElement.col
    for colIndex in currentCol..<endColNum {
        if dataMatrix[currentRow][colIndex] != 0 {
            return false
        }
    }
    return true
}

func findFirstEmptyColumnIndexOnRaw() -> Int {
    for colIndex in 0..<colMaxNum {
        if dataMatrix[currentRow][colIndex] == 0 {
            return colIndex
        }
    }
    return 0
}

func findPositionForElementOnGrid(_ currentElement: Element){
    if (currentCol == 0) && (currentRow == 0) {
        dataMatrix.append([])
        for _ in 0..<colMaxNum {
            dataMatrix[currentRow].append(0)
        }
    }
    if (!currentElement.append) && (currentCol != 0) {
        goToNextRow()
        currentCol = findFirstEmptyColumnIndexOnRaw()
        findPositionForElementOnGrid(currentElement)
    }
    if (currentCol + currentElement.col) > colMaxNum {
        goToNextRow()
        currentCol = findFirstEmptyColumnIndexOnRaw()
        findPositionForElementOnGrid(currentElement)
    }
    if !canAddOnRaw(currentElement){
        goToNextRow()
        currentCol = 0
        findPositionForElementOnGrid(currentElement)
    }
}

for currentElement in elements {
    findPositionForElementOnGrid(currentElement)
    addElementOnGrid(currentElement)
}

for i in 0..<dataMatrix.count{
    print(dataMatrix[i])
}



